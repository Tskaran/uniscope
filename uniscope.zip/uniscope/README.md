# 🎓 UniScope — Deployment Guide

> **100% FREE** — Powered by Google Gemini API (1,500 free searches/day) + Vercel (free hosting)

---

## What You Need
- A Google account (for Gemini API key)
- A GitHub account (free)
- A Vercel account (free)
- 20 minutes

---

## STEP 1 — Get Your Free Gemini API Key

1. Go to → https://aistudio.google.com/app/apikey
2. Click **"Create API Key"**
3. Copy the key — looks like: `AIzaSyXXXXXXXXXXXXXXXXXXXXXX`
4. Save it somewhere safe

> ✅ **Free tier = 1,500 requests/day** — perfect for your team

---

## STEP 2 — Upload to GitHub

1. Go to → https://github.com and sign in
2. Click **"New repository"** (green button)
3. Name it `uniscope`, set to **Private**, click **Create**
4. Click **"uploading an existing file"**
5. Upload ALL these files:
   ```
   index.html
   vercel.json
   package.json
   api/
     search.js
   ```
6. Click **"Commit changes"**

---

## STEP 3 — Deploy on Vercel (Free)

1. Go to → https://vercel.com and sign in with GitHub
2. Click **"Add New Project"**
3. Click **"Import"** next to your `uniscope` repository
4. Click **"Deploy"** (leave all settings as default)
5. Wait ~1 minute — it'll give you a live URL like:
   `https://uniscope-yourname.vercel.app`

---

## STEP 4 — Add Your API Key & Password (IMPORTANT)

Your API key must stay secret. Do this on Vercel:

1. In Vercel, go to your project → **Settings** → **Environment Variables**
2. Add these two variables:

   | Name | Value |
   |------|-------|
   | `GEMINI_API_KEY` | Paste your Gemini API key |
   | `TEAM_PASSWORD` | Choose a password for your team (e.g. `KC2025`) |

3. Click **Save**
4. Go to **Deployments** → click the 3 dots → **Redeploy**

---

## STEP 5 — Share With Your Team

1. Your app is live at: `https://uniscope-yourname.vercel.app`
2. Share the **URL + password** with your team
3. That's it! 🎉

---

## Changing the Password

1. Go to Vercel → Settings → Environment Variables
2. Edit `TEAM_PASSWORD`
3. Redeploy

---

## Checking Your Usage (Stay Free)

1. Go to → https://aistudio.google.com
2. Check your API usage dashboard
3. You get **1,500 free calls/day** — resets every 24 hours

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| "Wrong password" | Check TEAM_PASSWORD in Vercel env vars |
| "Could not load data" | Check GEMINI_API_KEY in Vercel env vars |
| API key not working | Make sure you copied the full key from Google AI Studio |
| Changes not showing | Redeploy on Vercel |

---

## File Structure
```
uniscope/
├── index.html       ← Main app (frontend + password gate)
├── vercel.json      ← Vercel routing config
├── package.json     ← Node config
└── api/
    └── search.js    ← Backend (hides your API key)
```

---

## Cost Summary

| Item | Cost |
|------|------|
| Vercel hosting | **FREE** |
| Gemini API (up to 1,500/day) | **FREE** |
| Custom domain (optional) | ~$10/year |
| **Total** | **$0/month** |

---

Made with ❤️ — UniScope Team
