export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Check team password
  const { university, password } = req.body;
  const TEAM_PASSWORD = process.env.TEAM_PASSWORD || 'uniscope2025';

  if (password !== TEAM_PASSWORD) {
    return res.status(401).json({ error: 'Invalid password' });
  }

  if (!university || university.trim().length < 2) {
    return res.status(400).json({ error: 'University name required' });
  }

  const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_API_KEY) {
    return res.status(500).json({ error: 'API key not configured' });
  }

  const prompt = `You are a university information expert. The user searched for: "${university.trim()}"

Return a comprehensive JSON object. Be accurate and specific. Use real data where possible. Return ONLY valid JSON — no markdown, no explanation, no code blocks.

{
  "university_name": "Full official name",
  "country": "Country",
  "city": "City",
  "type": "Public or Private or Research",
  "established": "Year as string",
  "website": "https://official-website.edu",
  "tagline": "One sentence describing the university's key distinction",
  "rankings": {
    "qs_world": "e.g. #5 or Not Ranked",
    "times_world": "e.g. #8 or Not Ranked",
    "us_news": "e.g. #12 or Not Ranked",
    "national_rank": "e.g. #2 in UK",
    "subject_strengths": ["e.g. Engineering #3 globally", "Business #10 globally"]
  },
  "tuition_fees": {
    "currency": "USD or GBP or EUR or AUD or CAD or INR etc.",
    "undergrad_domestic": "e.g. $12,000/yr or Free",
    "undergrad_international": "e.g. $45,000/yr",
    "postgrad_domestic": "e.g. $15,000/yr",
    "postgrad_international": "e.g. $38,000/yr",
    "mba": "e.g. $65,000 total or N/A",
    "living_costs": "e.g. $18,000–22,000/yr"
  },
  "admission_requirements": {
    "undergrad_gpa": "e.g. 3.8+ GPA or A*AA A-levels",
    "postgrad_gpa": "e.g. 3.5+ or First Class degree",
    "english_ielts": "e.g. 7.0 overall",
    "english_toefl": "e.g. 100 iBT",
    "gre_gmat": "e.g. GRE 320+ or GMAT 680+ or Not required",
    "work_exp_pg": "e.g. 2+ years for MBA or Not required",
    "acceptance_rate": "e.g. 17%",
    "application_deadline": "e.g. Jan 15 (Regular), Nov 1 (Early Action)"
  },
  "scholarships": [
    {
      "name": "Scholarship name",
      "amount": "e.g. Full tuition + living stipend",
      "eligibility": "Brief description of who qualifies",
      "renewable": true
    }
  ],
  "loan_providers": [
    {
      "name": "Loan provider name",
      "type": "Government or Private or University",
      "coverage": "e.g. Up to $50,000/yr",
      "interest": "e.g. 4.5%–7%",
      "notes": "Key eligibility conditions"
    }
  ],
  "popular_courses": ["Course 1", "Course 2", "Course 3", "Course 4", "Course 5", "Course 6"],
  "notable_alumni": ["Full Name (field/achievement)", "Full Name (field/achievement)", "Full Name (field/achievement)"],
  "student_population": "e.g. 24,000 students",
  "campus_size": "e.g. 65 acres urban campus",
  "research_output": "e.g. Top 10 globally for research citations",
  "accreditations": ["e.g. AACSB", "EQUIS", "AMBA"]
}`;

  try {
    const geminiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.2, maxOutputTokens: 2048 }
        })
      }
    );

    const geminiData = await geminiRes.json();
    const rawText = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || '';

    // Strip markdown code fences if present
    const cleaned = rawText.replace(/```json\n?/gi, '').replace(/```\n?/gi, '').trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error('No JSON in response');

    const uniData = JSON.parse(jsonMatch[0]);
    return res.status(200).json(uniData);

  } catch (err) {
    console.error('Gemini error:', err);
    return res.status(500).json({ error: 'Failed to fetch university data. Try again.' });
  }
}
